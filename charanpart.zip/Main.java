import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    System.out.println("Customer and Sales System\n\n1. Enter Customer Info.\n\n2. Generate Customer Info\n\n3. Report on Total Sales\n\n4. Check for fraud\n\n9. Quit");
  }
  public static getpostalCode(){
     boolean isPostalValid = false;
    String postalCode = "";
    while (!isPostalValid) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter customer postal code: ");
        postalCode = scanner.nextLine();
        isPostalValid = validatePostalCode(postalCode);
        if (!isPostalValid) {
            System.out.println("Postal code is not valid!");
        }
      return postalCode;
    }
    
  
    
  }
  public static void enterCustomerInfo(int currentId) {
    System.out.println("Enter customer first name: ");
    String firstName = scanner.nextLine();
    System.out.println("Enter customer last name: ");
    String lastName = scanner.nextLine();
    System.out.println("Enter customer city: ");
    String city = scanner.nextLine();
    String postalCode = getPostalCode();
    boolean isCCValid = false;
    String creditCardNum = "";
    while (!isCCValid) {
        System.out.print("Enter customer credit card number: ");
        creditCardNum = scanner.nextLine();
        isCCValid = validateCreditCard(creditCardNum);
        if (!isCCValid) {
            System.out.println("Credit card number is not valid!");
        }
    }
    // save customer
    String customer = String.format("%d,%s,%s,%s,%s,%s", currentId, firstName, lastName, city, postalCode, creditCardNum);
    customers.add(customer);
  }
  public static boolean validatePostalCode(String postalCode) {
    if (postalCode.length() < 3) {
        return false;
    } else {
        try {
            List<String> postalCodes = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new FileReader("postal_codes.csv"));
            String line = reader.readLine();
            while (line != null) {
                postalCodes.add(line.split("\\|")[0]);
                line = reader.readLine();
            }
            reader.close();
            if (!postalCodes.contains(postalCode.substring(0, 3))) {
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
  }
}

  
  
